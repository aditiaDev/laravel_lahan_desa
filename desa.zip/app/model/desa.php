<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class desa extends Model
{
    protected $table = 'desa';
    public $timestamps = false;
}
