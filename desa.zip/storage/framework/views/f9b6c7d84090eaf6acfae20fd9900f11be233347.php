<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2020 <a href="/home">Lahan Desa</a>.</strong> All rights
    reserved.
</footer><?php /**PATH E:\laravel\laravel_lahan_desa\resources\views/layouts/footer.blade.php ENDPATH**/ ?>