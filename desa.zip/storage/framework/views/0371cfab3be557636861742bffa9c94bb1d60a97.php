

<?php $__env->startSection('content'); ?>
   
<div class="content-wrapper">
    

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\laravel\laravel_lahan_desa\resources\views/contents/home.blade.php ENDPATH**/ ?>